<?php
//aqui estaran presente las rutas de los tipos de usuarios (propietario,admin,transcriptor)
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\logincontroller;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\principalcontroller;


/* Route::post('/login',[logincontroller::class,'login']);
Route::post('/register',[logincontroller::class, 'register']);

Route::middleware(['auth:sanctum'])->group(function(){

   Route::get('/logout',[logincontroller::class,'logout']);
}); */

//csv
Route::post('/csv-users',[RegisterController::class,'addUserMasivo']);

//listar usuario por admin
Route::get('/listado/{opcion}/{archivado}',[principalcontroller::class,'userOptionList']);

Route::get('/consultar/{id}',[principalcontroller::class,'unicoUser']);

Route::put('/modificar/{id}',[principalcontroller::class,'modificarUsuario']);

Route::delete('/eliminar/{id}',[principalcontroller::class,'eliminarUsuario']);

Route::put('/archivo/{id}/{tipoUsuario}/{archivado}',[principalcontroller::class,'archivarUsuario']);