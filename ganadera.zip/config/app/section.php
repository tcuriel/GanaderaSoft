<?php

return [
    'finca' => 'finca',
    'animal' => 'animal',
    'produccion' => 'produccion',
    'sanidad' => 'sanidad',
    'reporte' => 'reporte',
];
