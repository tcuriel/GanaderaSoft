<?php

return [
    'Activo' => 'Activo',
    'Archivado' => 'Archivado'
];
