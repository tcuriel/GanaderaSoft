<?php

return [
    //Crear finca
    'create_farm' => '/GanaderoSoft/Finca/crear-finca/',
    'update_farm' => '/GanaderoSoft/Finca/modificar-finca/,/GanaderoSoft/Finca/modificar-hierro/,/GanaderoSoft/Finca/modificar-terreno/',
    'add_renbano_farm' => '/GanaderoSoft/Finca/crear-rebano/',
    'add_personal_farm' => '/GanaderoSoft/Finca/ingresar-personal/',
    'update_personal_farm' => '/GanaderoSoft/Finca/actualizar-informacion/',
    'add_inventario_farm' => '/GanaderoSoft/Finca/inventario-',
    'create_animal' => '/GanaderoSoft/Animal/agregar-animal/',
    'up_file_animal' => '/GanaderoSoft/Animal/csv-agregar'
];
