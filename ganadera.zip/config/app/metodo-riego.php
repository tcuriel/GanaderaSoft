<?php

return [
    'Aspersión' => 'Aspersión',
    'Inundación' => 'Inundación',
    'Surco con salida' => 'Surco con salida',
    'Surco sin salida' => 'Surco sin salida',
    'Goteo' => 'Goteo',
];
