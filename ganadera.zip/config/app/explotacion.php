<?php

return [
    'Intensiva' => 'Intensiva',
    'Extensiva' => 'Extensiva',
    'Compuesta' => 'Compuesta',
];
