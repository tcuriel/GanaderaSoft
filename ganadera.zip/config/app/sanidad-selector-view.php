<?php

return [
    'sanidad' => 'Sanidad',
];
