<?php

return [
    'F' => 'Femenino',
    'M' => 'Masculino',
];
