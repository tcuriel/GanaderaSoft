<?php

return [
    'Sano' => 'Sano',
    'Enfermo' => 'Enfermo',
    'Muerto' => 'Muerto',
    'Servicio' => 'Servicio',
    'Preñez' => 'Preñez',
];
