<?php

return [
    'Activas' => 'Activas',
    'Archivados' => 'Archivados',
];
