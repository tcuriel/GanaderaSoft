<?php

return [
    'find_farm' => '/GanaderoSoft/Finca/finca/',
    'find_farmFUllData' => '/GanaderoSoft/Finca/fincafulldata/',
    'list_rebano' => '/GanaderoSoft/Finca/listar-rebano/',
    'get_rebano' => '/GanaderoSoft/Finca/get-rebano/',
    'list_personal' => '/GanaderoSoft/Finca/listar-personal/',
    'get_personal' => '/GanaderoSoft/Finca/get-personal/',
    'list_inventario' => '/GanaderoSoft/Finca/listar-inventario-',
    'get_inventario' => '/GanaderoSoft/Finca/inventario-',
    'list_animal' => '/GanaderoSoft/Animal/listar-animales/',
];
