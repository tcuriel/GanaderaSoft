<?php

return [
    'general' => 'Inventartio General',
    'vacuno' => 'Inventartio Vacuno',
    'bufalo' => 'Inventartio bufalo',
];
