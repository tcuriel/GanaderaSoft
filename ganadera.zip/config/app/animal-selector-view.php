<?php

return [
    'animal' => 'Animal',
];
