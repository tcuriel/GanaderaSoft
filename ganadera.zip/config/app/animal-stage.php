<?php

return [
    'Becerra' => 'Becerra',
    'Maute' => 'Maute',
    'Novilla' => 'Novilla',
    'Vaca' => 'Vaca',
];