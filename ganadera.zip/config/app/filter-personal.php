<?php

return [
    'Nombre' => 'Nombre',
];
