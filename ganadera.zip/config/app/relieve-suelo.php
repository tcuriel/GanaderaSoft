<?php

return [
    'Plano' => 'Plano',
    'Ondulado' => 'Ondulado',
    'Montañoso' => 'Montañoso',
];
