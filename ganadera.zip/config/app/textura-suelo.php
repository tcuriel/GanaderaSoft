<?php

return [
    'Arcilla' => 'Arcilla',
    'Arcillo arenoso' => 'Arcillo arenoso',
    'Arcillo limoso' => 'Arcillo limoso',
    'Franco arcilloso arenoso' => 'Franco arcilloso arenoso',
    'Franco arcilloso' => 'Franco arcilloso',
    'Limoso' => 'Limoso',
    'Franco arenoso' => 'Franco arenoso',
    'Franco' => 'Franco',
    'Arenoso francoso' => 'Arenoso francoso',
    'Arena' => 'Arena',
];
