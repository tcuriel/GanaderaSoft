<?php

return [
    'Vacuno' => 'Vacuno',
    'Bufala' => 'Bufala',
];
/*return [
    'Becerra' => 'Becerra',
    'Maute' => 'Maute',
    'Novilla' => 'Novilla',
    'Vaca' => 'Vaca',
];*/