<?php

return [
    'reporte' => 'Reporte',
];
