<?php

return [
    'produccion' => 'Produccion',
];
