<?php

return [
    'rebano' => 'Rebaño',
    'personal' => 'Personal',
    'afiliacion' => 'Afiliación',
    'inventario' => 'Inventario',
    'finca' => 'Mi Finca',
];
