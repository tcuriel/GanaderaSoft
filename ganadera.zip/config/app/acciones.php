<?php

return [
    'Propietario' => App\Http\Controllers\User\PropietarioController::class,
    'Ingenierio' => App\Http\Controllers\User\IngenierioController::class,
    'Veterinario' => App\Http\Controllers\User\VeterinarioController::class,
    'Asistente' => App\Http\Controllers\User\AsistenteController::class,
];
