<?php

return [
    'bufalo' => 'Bufalo',
    'general' => 'General',
    'vacuno' => 'Vacuno',
];
