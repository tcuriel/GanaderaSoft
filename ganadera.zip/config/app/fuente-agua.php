<?php

return [
    'Superficial' => 'Superficial',
    'Subterránea' => 'Subterránea',
    'Toma directa de rio' => 'Toma directa de rio',
    'Sistema de riego' => 'Sistema de riego',
];
