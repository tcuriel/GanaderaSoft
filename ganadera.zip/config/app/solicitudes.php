<?php

return [
    'pendientes' => 'Solicitudes Pendientes',
    'activas' => 'Solicitudes Activas',
];
