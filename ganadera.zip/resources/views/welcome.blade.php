@extends('adminlte::master')

@section('classes_body')
    row
    g-0
    min-vh-100
@stop

@section('adminlte_css')
    @vite(['resources/sass/app.scss', 'resources/sass/app/wellcome/styles.scss'])
@stop

@section('body')
    <div class="col-xl-11 ml-auto d-flex flex-column justify-content-center py-86">
        <div class="row m-0 h-100">
            <div class="col-md-4 d-flex flex-column justify-content-center">
                <div class="login-logo-colum">
                    <div class="complete-logo-app"></div>
                </div>
                <h2 class="title-blue">{{ config('app.name') }}</h2>
                <p class="text-wellcome">
                    Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.
                </p>
            </div>
            <div class="col-md-8 overflow-hidden">
                <div class="row g-0">
                    <!--div-- class="col-md-4 d-flex justify-content-center">
                        <a href="{{ route('register') }}" type="submit" class="btn btn-secundary btn-230">Registro</a>
                    </!--div-->
                    <div class=" col-md-4 d-flex justify-content-center">
                        <a href="{{ route('login') }}" type="button" class="btn btn-clear btn-230">Inicio de Sesión</a>
                    </div>
                    <div class=" col-md-4  d-flex justify-content-center">
                        <a href="{{ route('login') }}" type="button" class="btn btn-secundary btn-230">Acerca de</a>
                    </div>
                </div>
                <div class="frontpage-wellcome"></div>
            </div>
        </div>
    </div>
@stop
