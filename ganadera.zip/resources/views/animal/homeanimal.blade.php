<div id="listAnimal">
    <!--div-- class="row g-3 continer-item-list">
        <div class="col-7 mt-0 iconanimalcow">
            <h4 class="mb-1">Animal</h4>
            <p class="mb-1"></p>
        </div>
        <div class="col-5 mt-0 align-content-around text-right">
            <button type="button" id="listItem1" class="btn btn-secundary btn-secundary-darck">Ver Animal</button>
        </div>
    </!--div-->
    <div class="row g-3">
        <div class="col">
            <table id="table_id" class="display">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Código</th>
                        <th>Peso</th>
                        <th>Raza</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Row Nombre</td>
                        <td>Row Código</td>
                        <td>Row Peso</td>
                        <td>Row Raza</td>
                        <td>Row Acciones</td>
                    </tr>
                    <tr>
                        <td>Row Nombre</td>
                        <td>Row Código</td>
                        <td>Row Peso</td>
                        <td>Row Raza</td>
                        <td>Row Acciones</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
