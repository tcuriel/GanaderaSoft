<?php

namespace App\Models\modelanimal;

interface interfaceAnimal
{
    public function verificarRegistro($parametro);
}