<?php $__env->startSection('classes_body'); ?>
    row
    g-0
    min-vh-100
<?php $__env->stopSection(); ?>

<?php $__env->startSection('adminlte_css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/sass/app/wellcome/styles.scss']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="col-xl-11 ml-auto d-flex flex-column justify-content-center py-86">
        <div class="row m-0 h-100">
            <div class="col-md-4 d-flex flex-column justify-content-center">
                <div class="login-logo-colum">
                    <div class="complete-logo-app"></div>
                </div>
                <h2 class="title-blue"><?php echo e(config('app.name')); ?></h2>
                <p class="text-wellcome">
                    Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.
                </p>
            </div>
            <div class="col-md-8 overflow-hidden">
                <div class="row g-0">
                    <!--div-- class="col-md-4 d-flex justify-content-center">
                        <a href="<?php echo e(route('register')); ?>" type="submit" class="btn btn-secundary btn-230">Registro</a>
                    </!--div-->
                    <div class=" col-md-4 d-flex justify-content-center">
                        <a href="<?php echo e(route('login')); ?>" type="button" class="btn btn-clear btn-230">Inicio de Sesión</a>
                    </div>
                    <div class=" col-md-4  d-flex justify-content-center">
                        <a href="<?php echo e(route('login')); ?>" type="button" class="btn btn-secundary btn-230">Acerca de</a>
                    </div>
                </div>
                <div class="frontpage-wellcome"></div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/felix/Ganaderosoft/GanaderoSoft-Dev/bdganadera-pedro/ganaderosoft/resources/views/welcome.blade.php ENDPATH**/ ?>