<div class="row">
    <div class="col-12">
        <a href="<?php echo e(route('home')); ?>" class="gren-text-color font-weight-bold float-right my-3 d-block"> Listado de fincas</a>
    </div>
    <div class="col-12">
        <div class="row g-3">
            <div class="col-12 col-md-6">
                <div class="row g-3 align-items-center">
                    <form action="" class="form-app">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label for="selectView" class="col-sm-3 col-form-label gren-text-color title-selector-views">¿Qué deseas ver?</label>
                            <div class="col-sm-auto">
                                <select class="form-select"
                                    id="selectView"
                                    name="selectView"
                                    aria-label="select type Exploitation"
                                    onchange="selectorView(this.value)"
                                    required>
                                    <?php $__currentLoopData = $selectorViews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clave => $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($clave != $selectView): ?>
                                            <option value="<?php echo e($clave); ?>"><?php echo e($valor); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($clave); ?>" selected><?php echo e($valor); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-12 col-md-6">
            <?php if($selectView == "rebano"): ?>
                <a href="<?php echo e(url('dashboard/finca/rebano/agregar/'.$data[0]->id_Finca)); ?>" id="addRebano" class="btn btn-primary btn-primary-darck float-right">Agregar Rebaño <i class="fas fa-fw fa-plus"></i> </a>
            <?php elseif($selectView == 'personal'): ?>
                <a href="<?php echo e(url('dashboard/finca/personal/agregar/'.$data[0]->id_Finca)); ?>" id="addPersonal" class="btn btn-primary btn-primary-darck float-right">Agregar Personal <i class="fas fa-fw fa-plus"></i> </a>
            <?php elseif($selectView == 'afiliacion'): ?>
                <a href="<?php echo e(url('dashboard/finca/afiliacion/'.$data[0]->id_Finca)); ?>" id="addAfiliacion" class="btn btn-primary btn-primary-darck float-right">Añadir Afiliacion <i class="fas fa-fw fa-plus"></i> </a>
            <?php elseif($selectView == 'inventario'): ?>
                <a href="<?php echo e(url('dashboard/finca/inventario/agregar/'.$data[0]->id_Finca)); ?>" id="addInventario" class="btn btn-primary btn-primary-darck float-right">Añadir Inventario <i class="fas fa-fw fa-plus"></i> </a>
            <?php elseif($selectView == 'finca'): ?>
                <!--a href="<?php echo e(url('dashboard/finca/rebano/'.$data[0]->id_Finca)); ?>" id="fincaUp" class="btn btn-primary btn-primary-darck float-right"> </!--a-->
                <div class="btn-toolbar justify-content-end" role="toolbar" aria-label="Toolbar with button groups">
                    <div class="btn-group mr-2" role="group">
                        <button type="button" id="fincaSave" class="btn btn-primary float-right"><i class="fa fa-file"></i> Archivar</button>
                    </div>
                    <div class="btn-group mr-2" role="group">
                        <button type="button" id="fincaDelete" class="btn btn-danger float-right"><i class="fa fa-minus"></i> Eliminar</button>
                    </div>
                </div>
            <?php endif; ?>
            </div>
        </div>
    </div>
    <div id="contenedor-blade" class="col-12">

        <?php if($selectView == "rebano"): ?>
            <?php echo $__env->make('finca.homerebano', ['statusRebanoFarms' => config('app.filter-renano')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($selectView == 'personal'): ?>
            <?php echo $__env->make('finca.homepersonal', ['statusPersonalFarms' => config('app.filter-personal')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($selectView == 'afiliacion'): ?>
            <?php echo $__env->make('finca.homeafiliacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($selectView == 'inventario'): ?>
            <?php echo $__env->make('finca.homeinventario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($selectView == 'finca'): ?>
            <?php echo $__env->make('finca.homefinca', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

    </div>
</div>
<?php $__env->startSection('js-content-home'); ?>
        <script>
            function selectorView(view) {
                const section = "<?php echo e($section); ?>";
                const id_finca = "<?php echo e($data[0]->id_Finca); ?>"
                const URL = "/dashboard/" + section + "/" + view + "/" + id_finca;
                window.location.href =URL;
            }
            window.dataFinca = '<?php echo json_encode($data); ?>';
        </script>
    <?php if($selectView == "rebano"): ?>
        <script>
            window.list_rebano = "<?php echo e(config('app.action-get-urls.list_rebano')); ?>";
            window.get_rebano = "<?php echo e(config('app.action-get-urls.get_rebano')); ?>";
        </script>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/finca/homefincarebano.js']); ?>
    <?php elseif($selectView == 'personal'): ?>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
        <script>
            window.list_personal = "<?php echo e(config('app.action-get-urls.list_personal')); ?>";
            window.get_personal = "<?php echo e(config('app.action-get-urls.get_personal')); ?>";
        </script>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/finca/homefincapersonal.js']); ?>
    <?php elseif($selectView == 'afiliacion'): ?>
    <script>console.log("HOLA afiliacion");</script>
    <?php elseif($selectView == 'inventario'): ?>
        <script>
            window.list_inventario = "<?php echo e(config('app.action-get-urls.list_inventario')); ?>";
            window.get_inventario = "<?php echo e(config('app.action-get-urls.get_inventario')); ?>";
            window.inventario_selector = "<?php echo e(implode(',', array_keys(config('app.inventario-selector')))); ?>";
        </script>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/finca/homefincainventario.js']); ?>
    <?php elseif($selectView == 'finca'): ?>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
        <script>
            window.actionGet = "<?php echo e(config('app.action-get-urls.find_farmFUllData')); ?>";
        </script>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/finca/homefincamifinca.js']); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/felix/Ganaderosoft/GanaderoSoft-Dev/bdganadera-pedro/ganaderosoft/resources/views/finca/home.blade.php ENDPATH**/ ?>