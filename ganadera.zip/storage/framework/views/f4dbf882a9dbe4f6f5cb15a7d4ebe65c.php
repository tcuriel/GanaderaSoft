<?php $__env->startSection('css-content'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/sass/app/finca/stylefrontpagefinca.scss'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-content'); ?>
<div-- class="row">
    <div class="col content d-flex flex-column justify-content-center">
        <h2 class="title-blue">¡Hola! <?php echo e($user->name); ?> vemos que no posees una Finca para gestionarla</h2>
        <p class="text-wellcome">Si deseas crear una Finca, presiona el siguiente botón:</p>
        <a href="<?php echo e(route('createMyFarm')); ?>" type="button" class="btn btn-secundary">Crear Finca</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/felix/Ganaderosoft/GanaderoSoft -Dev/bdganadera-pedro/ganaderosoft/resources/views/finca/frontpagefinca.blade.php ENDPATH**/ ?>