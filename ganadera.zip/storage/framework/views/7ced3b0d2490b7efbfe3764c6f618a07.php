<?php $__env->startSection('adminlte_css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss']); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app/ganadegasof.scss']); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app/home/homestyle.scss']); ?>
    <?php if($section == "finca"): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app/finca/homefinca.scss']); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', env('APP_NAME', 'GanaderoSoft')); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="m-0 gren-text-color">Bienvenido a <?php echo e($data[0]->Nombre); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($section == "finca"): ?>
        <?php echo $__env->make('finca.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($section == 'animal'): ?>
        <p>Animal</p>
    <?php elseif($section == 'produccion'): ?>
        <p>Produccion</p>
    <?php elseif($section == 'sanidad'): ?>
        <p>Sanidad</p>
    <?php elseif($section == 'reporte'): ?>
        <p>Reporte</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        let navItems = document.querySelectorAll('.nav-pills .nav-link');
        let sectionName = "<?php echo e($section); ?>";
        let viewName = "<?php echo e($selectView); ?>";
        let navItem = document.getElementById(sectionName + 'Section');
        if (navItem) {
            const navLink = navItem.querySelector('.nav-link');
            navLink.classList.add('active');
        }
        for (const navItem of navItems) {
            const href = navItem.getAttribute('href');
            navItem.setAttribute('href', href + "/<?php echo e($data[0]->id_Finca); ?>" );
        }
    </script>
    <?php echo $__env->yieldContent('js-content-home'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/felix/Ganaderosoft/GanaderoSoft -Dev/bdganadera-pedro/ganaderosoft/resources/views/home.blade.php ENDPATH**/ ?>