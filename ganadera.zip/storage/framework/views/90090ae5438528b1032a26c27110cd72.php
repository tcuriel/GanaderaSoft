<?php $layoutHelper = app('JeroenNoten\LaravelAdminLte\Helpers\LayoutHelper'); ?>

<?php $__env->startSection('adminlte_css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/sass/app/layouts/styles.scss']); ?>
    <?php echo $__env->yieldContent('css-content'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('classes_body'); ?>
    body-page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    
    <?php if($layoutHelper->isPreloaderEnabled()): ?>
        <?php echo $__env->make('adminlte::partials.common.preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    

    <?php echo $__env->make('partials.navbar.navba-page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="wrapper d-flex flex-column justify-content-center">

        <?php echo $__env->yieldContent('body-content'); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('adminlte_js'); ?>
    <?php echo $__env->yieldContent('js-content'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/felix/Ganaderosoft/GanaderoSoft-Dev/bdganadera-pedro/ganaderosoft/resources/views/layouts/page.blade.php ENDPATH**/ ?>