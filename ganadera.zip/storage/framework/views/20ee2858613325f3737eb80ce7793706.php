<?php $__env->startSection('css-content'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/sass/app/finca/stylewelcomefarm.scss'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('welcome-user'); ?>
    <h2 class="welcome-user">Bienvenido <?php echo e($user->name); ?>.</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-content'); ?>
  <?php echo $__env->make('finca.formwelcomefarms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-content'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/finca/welcomefincaform.js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/felix/Ganaderosoft/GanaderoSoft -Dev/bdganadera-pedro/ganaderosoft/resources/views/finca/welcome.blade.php ENDPATH**/ ?>