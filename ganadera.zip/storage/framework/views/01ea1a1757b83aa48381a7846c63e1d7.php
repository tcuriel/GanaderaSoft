<?php $__env->startSection('css-content'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/sass/app/finca/formcreatefinca.scss'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-content'); ?>
    <?php echo $__env->make('animal.formcreateanimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-content'); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        window.dataFinca = '<?php echo json_encode($data); ?>';
    </script>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/animal/createanimal.js']); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/felix/Ganaderosoft/GanaderoSoft-Dev/bdganadera-pedro/ganaderosoft/resources/views/animal/createanimal.blade.php ENDPATH**/ ?>