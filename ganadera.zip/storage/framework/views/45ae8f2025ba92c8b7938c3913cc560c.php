<nav class="main-header navbar
    
    <?php echo e(config('adminlte.classes_topnav_nav', 'navbar-expand-md')); ?>

    <?php echo e(config('adminlte.classes_topnav', 'navbar-white navbar-light')); ?>">

    <div class="<?php echo e(config('adminlte.classes_topnav_container', 'container')); ?>">

        
        <?php echo $__env->make('adminlte::partials.common.brand-logo-xs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php echo $__env->yieldContent('welcome-user'); ?>

        
        <button class="navbar-toggler order-1" type="button" data-toggle="collapse" data-target="#navbarCollapse"
                aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse order-3" id="navbarCollapse">
            
            <ul class="nav navbar-nav">
                
                <?php
                //<!--@each('adminlte::partials.navbar.menu-item', $adminlte->menu('navbar-left'), 'item')-->
                ?>
                
                <?php echo $__env->yieldContent('content_top_nav_left'); ?>
            </ul>
        </div>
        
        <ul class="navbar-nav ml-auto order-1 order-md-3 navbar-no-expand">

            <?php ( $logout_url = View::getSection('logout_url') ?? config('adminlte.logout_url', 'logout') ); ?>

            <?php if(config('adminlte.use_route_url', false)): ?>
                <?php ( $logout_url = $logout_url ? route($logout_url) : '' ); ?>
            <?php else: ?>
                <?php ( $logout_url = $logout_url ? url($logout_url) : '' ); ?>
            <?php endif; ?>

            <li class="nav-item dropdown user-menu">
                
                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
                    <?php if(config('adminlte.usermenu_image')): ?>
                        <img src="<?php echo e(Auth::user()->adminlte_image()); ?>"
                            class="user-image img-circle elevation-2"
                            alt="<?php echo e(Auth::user()->name); ?>">
                    <?php endif; ?>
                    <span <?php if(config('adminlte.usermenu_image')): ?> class="d-none d-md-inline" <?php endif; ?>>
                        <?php echo e(Auth::user()->name); ?>

                    </span>
                </a>
                <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                    <li class="user-footer">
                        <a class="btn btn-default btn-flat float-right btn-block"
                        href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            <i class="fa fa-fw fa-power-off text-red"></i>
                            <?php echo e(__('adminlte::adminlte.log_out')); ?>

                        </a>
                        <form id="logout-form" action="<?php echo e($logout_url); ?>" method="POST" style="display: none;">
                            <?php if(config('adminlte.logout_method')): ?>
                                <?php echo e(method_field(config('adminlte.logout_method'))); ?>

                            <?php endif; ?>
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
</nav>
<?php /**PATH /home/felix/Ganaderosoft/GanaderoSoft-Dev/bdganadera-pedro/ganaderosoft/resources/views/partials/navbar/navba-page.blade.php ENDPATH**/ ?>