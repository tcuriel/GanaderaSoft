<div class="row">
    <div class="col-12">
        <a href="<?php echo e(route('home')); ?>" class="gren-text-color font-weight-bold float-right my-3 d-block"> Listado de fincas</a>
    </div>
    <div class="col-12">
        <div class="row g-3">
            <div class="col-12 col-md-6">
                <div class="row g-3 align-items-center">
                    <form action="" class="form-app">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label for="selectView" class="col-sm-3 col-form-label gren-text-color title-selector-views">¿Qué deseas ver?</label>
                            <div class="col-sm-auto">
                                <select class="form-select"
                                    id="selectView"
                                    name="selectView"
                                    aria-label="select type Exploitation"
                                    onchange="selectorView(this.value)"
                                    required>
                                        <option value="animal" selected>Animal</option>
                                </select>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-12 col-md-6">
            <?php if($selectView == "animal"): ?>
            <div class="row g-3">
                <div class="col-12">
                    <a href="<?php echo e(url('/finca/animal/agregar/'.$data[0]->id_Finca)); ?>" id="addRebano" class="btn btn-primary btn-primary-darck float-right">Agregar Animal <i class="fas fa-fw fa-plus"></i> </a>
                </div>
                <div class="col-12">
                    <a href="<?php echo e(url('/finca/rebano/'.$data[0]->id_Finca.'/up/'.$listRebano[0]->id_Rebano)); ?>" id="addRebanoLot" class="btn btn-primary btn-primary-darck float-right">Subir Animales <i class="fas fa-fw fa-plus"></i> </a>
                </div>
            </div>
            <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-6">
        <div class="row g-3 align-items-center">
            <form action="" id="rebanoSelect" class="form-app">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                    <label for="herd" class="col-sm-3 col-form-label gren-text-color title-selector-views">Selecciona un Rebaño</label>
                    <div class="col-sm-auto">
                        <select class="form-select"
                            id="herd"
                            name="herd"
                            aria-label="select type Herd"
                            required>
                                <?php $__currentLoopData = $listRebano; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clave => $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($loop->first): ?>
                                        <option value="<?php echo e($valor->id_Rebano); ?>" selected><?php echo e($valor->Nombre); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($valor->id_Rebano); ?>"><?php echo e($valor->Nombre); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div id="contenedor-blade" class="col-12">

        <?php if($selectView == "animal"): ?>
            <?php echo $__env->make('animal.homeanimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

    </div>
</div>
<?php $__env->startSection('js-content-home'); ?>
        <script>
            function selectorView(view) {
                const section = "<?php echo e($section); ?>";
                const id_finca = "<?php echo e($data[0]->id_Finca); ?>"
                const URL = "/dashboard/" + section + "/" + view + "/" + id_finca;
                window.location.href =URL;
            }
            window.dataFinca = '<?php echo json_encode($data); ?>';
            window.dataRebano = '<?php echo json_encode($listRebano); ?>';
        </script>
    <?php if($selectView == "animal"): ?>
        <script>
            window.list_animal = "<?php echo e(config('app.action-get-urls.list_animal')); ?>";
        </script>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/animal/homeanimal.js']); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/felix/Ganaderosoft/GanaderoSoft-Dev/bdganadera-pedro/ganaderosoft/resources/views/animal/home.blade.php ENDPATH**/ ?>