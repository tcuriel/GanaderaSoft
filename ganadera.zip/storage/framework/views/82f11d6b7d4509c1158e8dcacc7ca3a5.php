<?php $__env->startSection('css-content'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/sass/app/finca/formcreatefinca.scss'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-content'); ?>
    <?php echo $__env->make('finca.formcreatefinca', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-content'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/finca/createfincaform.js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/felix/Ganaderosoft/GanaderoSoft -Dev/bdganadera-pedro/ganaderosoft/resources/views/finca/createmyfarm.blade.php ENDPATH**/ ?>